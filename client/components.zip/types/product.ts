export interface PostBodyData {
  endpoint: string;
  header: any;
  body: any;
}
export interface GetBodyData {
  endpoint: string;
  header: any;
}
